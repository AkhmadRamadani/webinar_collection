!INITIAL COMMIT

1. Pindah ke htdocs dulu
2. Clone dulu gais
3. Composer install dulu jangan lupa
4. Coba buka di browser
